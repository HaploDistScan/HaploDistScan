plot_hap_dist_scan <-
function(hap_dist_scan, window_df, filter_cutoff = 50, tracks = c("sd", "dip", "snps"), pdf_file = "", svg_file = ""){
	
	if (pdf_file != "") pdf(pdf_file)
	else if (svg_file != "") svg(svg_file)
	
	win_filter <- hap_dist_scan$n_snps > filter_cutoff 
	par(mfrow=c(length(tracks),1), mar = c(3.5,4,.5,3), xpd = NA)
	col_vec <- match(as.integer(as.factor(window_df[win_filter, 1])), unique(as.integer(as.factor(window_df[win_filter, 1])))) %% 2 + 1
	
	sd_thresh <- qnorm(1-0.05/length(hap_dist_scan$rel_sd), mean = mean(hap_dist_scan$rel_sd[win_filter]), sd = sd(hap_dist_scan$rel_sd[win_filter]))
	sd_top_pos <- which(hap_dist_scan$rel_sd > sd_thresh & win_filter)
	if("sd" %in% tracks){
		plot(y = hap_dist_scan$rel_sd[win_filter], x = window_df[win_filter, 4], col = col_vec, cex = 0.1, xlab = "", ylab = "Relative standard deviation")
		abline(h = sd_thresh, xpd = F, lwd = 0.5, col = "grey30")
	}
	
	dip_thresh <- qnorm(1-0.05/length(hap_dist_scan$dip_stat), mean = mean(hap_dist_scan$dip_stat[win_filter]), sd = sd(hap_dist_scan$dip_stat[win_filter]))
	dip_top_pos <- which(hap_dist_scan$dip_stat > dip_thresh & win_filter)
	if("dip" %in% tracks){
		plot(y = hap_dist_scan$dip_stat[win_filter], x = window_df[win_filter, 4], col = col_vec, cex = 0.1, xlab = "", ylab = "'Dip-test' statistic")
		abline(h = dip_thresh, xpd = F, lwd = 0.5, col = "grey30")
	}
	
	diff_thresh <- qnorm(1-0.05/length(hap_dist_scan$rel_diff), mean = mean(hap_dist_scan$rel_diff[win_filter]), sd = sd(hap_dist_scan$rel_diff[win_filter]))
	diff_top_pos <- which(hap_dist_scan$rel_diff > diff_thresh & win_filter)
	if("diff" %in% tracks){
		plot(y = hap_dist_scan$rel_diff[win_filter], x = window_df[win_filter, 4], col = col_vec, cex = 0.1, xlab = "", ylab = "Relative range")
		abline(h = diff_thresh, xpd = F, lwd = 0.5, col = "grey30")
	}
	if("snps" %in% tracks){
		col_vec <- match(as.integer(as.factor(window_df[, 1])), unique(as.integer(as.factor(window_df[, 1])))) %% 2 + 1
		plot(y = hap_dist_scan$n_snps, x = window_df[, 4], col = col_vec, cex = 0.1, xlab = "", ylab = "Number of SNPs")
	}
	title(xlab = "Cumulative position (bases)", line = 2)
	
	if (pdf_file != "" | svg_file != "" ) dev.off()
	
	return(list(sd = sd_top_pos , dip = dip_top_pos, diff = diff_top_pos, sd_t = sd_thresh , dip_t = dip_thresh, diff_t = diff_thresh))

}
