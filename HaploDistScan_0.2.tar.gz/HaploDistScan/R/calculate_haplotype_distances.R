calculate_haplotype_distances <-
function(geno, win_df){
	win_scaff_names <- unique(win_df[,1])
	rel_sd_score <- array(dim = dim(win_df)[1])
	rel_max_score <- array(dim = dim(win_df)[1])
	rel_diff_score <- array(dim = dim(win_df)[1])
	dip_test_stat <- array(dim = dim(win_df)[1])
	win_n_snps <- array(dim = dim(win_df)[1])
	
	win_count <- 1
	
	for(scaff in win_scaff_names){
		scaff_geno <- geno[geno[,1] == scaff,]
		win_starts <- win_df[win_df == scaff,2]
		win_stops <- win_df[win_df == scaff,3]
		for(j in 1:length(win_starts)){
			target_markers <- scaff_geno[,2] >= win_starts[j] & scaff_geno[,2] < win_stops[j]
			target_geno <- scaff_geno[target_markers,]
			n_haps <- nchar(target_geno[1,3])
			hap_vec <- array()
			for(i in 1:n_haps){
				 hap_vec[i] <- paste(substr(target_geno[,3], i, i), collapse = "")
			}
			hap_dist_mat <- outer(hap_vec, hap_vec, FUN = "stringdist", method = "hamming")
			diag(hap_dist_mat) <- NA
			hap_dist_data <- array(data = hap_dist_mat[!is.na(hap_dist_mat)])
			rel_sd_score[win_count] <- sd(hap_dist_data)/nchar(hap_vec[1])
			rel_diff_score[win_count] <- diff(range(hap_dist_data))/nchar(hap_vec[1])
			dip_test_stat[win_count] <- dip.test(hap_dist_data)$statistic
			win_n_snps[win_count] <- nchar(hap_vec[1])
			win_count <- win_count + 1
		}
	}
	return(list(rel_sd = rel_sd_score, rel_diff = rel_diff_score, dip_stat = dip_test_stat, n_snps = win_n_snps))
}
