plot_top_regions <- function(top_pos, win_df, geno, sample_list = NULL, plot_dir = ""){
	hclust_list <- list()
	for (pos in top_pos){
		win <- win_df[pos,]
		scaff_geno <- geno[geno[,1] ==  win[1,1],]
		target_markers <- scaff_geno[,2] >= win[1,2] & scaff_geno[,2] < win[1,3]
		target_geno <- scaff_geno[target_markers,]
		n_haps <- nchar(target_geno[1,3])
		hap_vec <- array()
		for(i in 1:n_haps){
			hap_vec[i] <- paste(substr(target_geno[,3], i, i), collapse = "")
		}
		hap_dist_mat <- outer(hap_vec, hap_vec, FUN = "stringdist", method = "hamming")
		diag(hap_dist_mat) <- NA
		hap_dist_data <- array(data = hap_dist_mat[!is.na(hap_dist_mat)])
			
		if (is.null(sample_list)) sample_list <- 1:n_haps
		rownames(hap_dist_mat) <- sample_list
		colnames(hap_dist_mat) <- sample_list
		win_loc <- paste(win[1], "_", round(win[2]/1000), "_to_", round(win[3]/1000), "_kb", sep = "")
		pdf(paste(plot_dir, win_loc, ".pdf", sep = ""), width = 14, height = 10, paper = "a4r")
		hist(hap_dist_data, main = win_loc, xlab = "Edit distance")
		hap_hc <- hclust(as.dist(hap_dist_mat))
		plot(hap_hc, xlab ="", ann = F, cex = min(c(1, 60/length(sample_list))))
		title(main = win_loc)
		heatmap(x= hap_dist_mat, scale = "none", margins = c(4,4), Rowv = as.dendrogram(hap_hc), Colv = as.dendrogram(hap_hc), cexRow = min(c(1, 35/length(sample_list))), labCol = "")
		dev.off()
		hclust_list[[win_loc]] <- hap_hc
	}
	return(hclust_list)
}