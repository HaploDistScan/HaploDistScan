plot_top_regions <- function(top_pos, win_df, geno, sample_list = NULL, plot_dir = "", snp_col = "orange", snp_lwd = 0.1, snp_alpha = 50){
	hclust_list <- list()
	for (pos in top_pos){
		win <- win_df[pos,]
		scaff_geno <- geno[geno[,1] ==  win[1,1],]
		target_markers <- scaff_geno[,2] >= win[1,2] & scaff_geno[,2] < win[1,3]
		target_geno <- scaff_geno[target_markers,]
		n_haps <- nchar(target_geno[1,3])
		hap_vec <- array()
		for(i in 1:n_haps){
			hap_vec[i] <- paste(substr(target_geno[,3], i, i), collapse = "")
		}
		hap_dist_mat <- outer(hap_vec, hap_vec, FUN = "stringdist", method = "hamming")
		diag(hap_dist_mat) <- NA
		hap_dist_data <- array(data = hap_dist_mat[!is.na(hap_dist_mat)])
			
		if (is.null(sample_list)) sample_list <- 1:n_haps
		rownames(hap_dist_mat) <- sample_list
		colnames(hap_dist_mat) <- sample_list
		win_loc <- paste(win[1], "_", round(win[2]/1000), "_to_", round(win[3]/1000), "_kb", sep = "")
		pdf(paste(plot_dir, win_loc, ".pdf", sep = ""), width = 14, height = 10, paper = "a4r")
		
		#Distance distribution histogram
		hist(hap_dist_data, main = win_loc, xlab = "Edit distance")
		
		#Dendrogram
		hap_hc <- hclust(as.dist(hap_dist_mat))
		plot(hap_hc, xlab ="", ann = F, cex = min(c(1, 60/length(sample_list))))
		title(main = win_loc)
		
		#Heatmap
		block_hm <- heatmap(x= hap_dist_mat, scale = "none", margins = c(4,4), Rowv = as.dendrogram(hap_hc), Colv = as.dendrogram(hap_hc), cexRow = min(c(1, 35/length(sample_list))), labCol = "")
		
		#Haplotype visualisation
		ext_start <- max(pos-5, min(which(win_df[,1] == win[1,1])))
		ext_stop <- min(pos+5, max(which(win_df[,1] == win[1,1])))
		ext_target_m <- scaff_geno[,2] >= win_df[ext_start,2] & scaff_geno[,2] < win_df[ext_stop,3]
		ext_target_g <- scaff_geno[ext_target_m,]
		for(i in 1:n_haps){
			hap_vec[i] <- paste(substr(ext_target_g[,3], i, i), collapse = "")
		}
		plot(1:n_haps, type = "n", xlim = range(ext_target_g[,2]), axes = F, ann = F)
		axis(2, labels = sample_list[block_hm$rowInd], at = 1:n_haps, las = 2, cex.axis= min(c(0.6, 35/n_haps)), col=1:2, pos = range(ext_target_g[,2])[1] - 0.0175*diff(range(ext_target_g[,2])))
		axis(1)
		title(main = win_loc)
		rect(range(ext_target_g[,2])[1]- 0.0025*diff(range(ext_target_g[,2])),0,range(ext_target_g[,2])[2] + 0.0025*diff(range(ext_target_g[,2])), n_haps+1, col = "grey90")
		rect(range(target_geno[,2])[1],0.1,range(target_geno[,2])[2], n_haps+0.9, col = "grey80", border = NA)
		#rect(range(ext_target_g[,2])[1] - 0.015*diff(range(ext_target_g[,2])), which(block_hm$rowInd == 1)-0.4, range(ext_target_g[,2])[1] - 0.005*diff(range(ext_target_g[,2])), which(block_hm$rowInd == 1) +0.4, col = "orange")
		#ref_col <- factor(unlist(strsplit(hap_vec[1], "")), levels = c("G", "C", "T", "A"))
		allele_df <- data.frame("G" = 1:dim(ext_target_g)[1], "C" = 0, "T" = 0, "A" = 0, "major" = NA, stringsAsFactors = F)
		allele_df[,"G"] <- nchar(gsub("[^G]", "",ext_target_g[,3]))
		allele_df[,"C"] <- nchar(gsub("[^C]", "",ext_target_g[,3]))
		allele_df[,"T"] <- nchar(gsub("[^T]", "",ext_target_g[,3]))
		allele_df[,"A"] <- nchar(gsub("[^A]", "",ext_target_g[,3]))			
		allele_max_vec <- pmax(allele_df[,"G"], allele_df[,"C"], allele_df[,"T"], allele_df[,"A"])
		allele_df[allele_df[,"G"] == allele_max_vec,"major"] <- "G"
		allele_df[allele_df[,"C"] == allele_max_vec,"major"] <- "C"
		allele_df[allele_df[,"T"] == allele_max_vec,"major"] <- "T"
		allele_df[allele_df[,"A"] == allele_max_vec,"major"] <- "A"
		ref_col <- factor(allele_df[,"major"], levels = c("G", "C", "T", "A"))
		for(i in 1:n_haps){
			tmp_col <- factor(unlist(strsplit(hap_vec[i], "")), levels = c("G", "C", "T", "A"))
			y_vec <- rep(which(block_hm$rowInd == i), length(tmp_col))[tmp_col != ref_col]
			x_vec <- ext_target_g[,2][tmp_col != ref_col]
			#rect(x_vec, y_vec-0.4 , x_vec + 0.001*diff(range(ext_target_g[,2])), y_vec+0.4, col = rgb(t(col2rgb("orange")), alpha = 100, max= 255), border = NA)
			segments(x0 = x_vec, y0 = y_vec-0.4, y1 = y_vec+0.4, col = rgb(t(col2rgb(snp_col)),alpha = min(c(snp_alpha,100*(10000/length(tmp_col)))) , maxColorValue= 255), lwd = snp_lwd)
			#alpha = min(c(50,100*(1000/length(x_vec))))
		}
		segments(x0 = range(target_geno[,2]), y0 = 0.05, y1 = n_haps + 0.95)
		dev.off()
		hclust_list[[win_loc]] <- hap_hc
	}
	return(hclust_list)
}
