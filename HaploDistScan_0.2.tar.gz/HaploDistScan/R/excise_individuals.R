excise_individuals <- function(geno, omission_list, inclusion_list = NULL, sample_list = NULL){
	if(is.null(sample_list)){
		omission_vec <- omission_list
	}else if(!is.null(inclusion_list)){
		omission_vec <- which(!sample_list %in% inclusion_list)
	}else{
		omission_vec <- which(sample_list %in% omission_list)
	}
	om_starts <- omission_vec[c(T, !diff(omission_vec) == 1)]
	om_stops <- omission_vec[c(!diff(omission_vec) == 1, T)]
	
	for(i in 1:length(om_starts)){
		substr(geno[,3], om_starts[i], om_stops[i]) <- paste(rep(" ", times = om_stops[i] - om_starts[i] + 1), collapse = "")
	}
	geno[,3] <- gsub(" ", "", geno[,3])
	return(geno)
}