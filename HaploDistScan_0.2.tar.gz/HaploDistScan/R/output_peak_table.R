output_peak_table <-
function(top_pos_set, window_df, file_prefix = "", write_files = F, hap_dist_scan = NULL){
	if(file_prefix == ""){
		file_prefix <- sub("top_pos", "", deparse(substitute(top_pos_set)))
	}
	dip_df <- data.frame(Scaffold = window_df[top_pos_set$dip,1], Start = round(window_df[top_pos_set$dip,2]/1e3),  Stop = round(window_df[top_pos_set$dip,3]/1e3), stringsAsFactors = F)
	if(!is.null(hap_dist_scan)) dip_df[,"dip_stat"] <- hap_dist_scan$dip_stat[top_pos_set$dip]
	order_vec <- order(as.numeric(sub("[A-Za-z]*", "", dip_df[, "Scaffold"])))
	dip_df <- dip_df[order_vec,]
	sd_df <- data.frame(Scaffold = window_df[top_pos_set$sd,1], Start = round(window_df[top_pos_set$sd,2]/1e3),  Stop = round(window_df[top_pos_set$sd,3]/1e3), stringsAsFactors = F)
	if(!is.null(hap_dist_scan)) sd_df[,"rel_sd"] <- hap_dist_scan$rel_sd[top_pos_set$sd]
	order_vec <- order(as.numeric(sub("[A-Za-z]*", "", sd_df[, "Scaffold"])))
	sd_df <- sd_df[order_vec,]
	
	out_list <- list(dip = dip_df, sd = sd_df)
	if (write_files){
		write.table(out_list$dip, row.names = F, quote = F, file = paste(file_prefix,"_dip_peaks.txt", sep = ""), sep  ="\t")
		write.table(out_list$sd, row.names = F, quote = F, file = paste(file_prefix,"_sd_peaks.txt", sep = ""), sep  ="\t")
	}
	return(out_list)
}
