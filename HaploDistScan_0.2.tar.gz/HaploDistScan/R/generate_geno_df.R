generate_geno_df <- function(infile = "", file_format = "s"){
	samples = ""
	prefix = paste(R.home("library"), "/HaploDistScan", sep = "")
	if (file_format == "b"){
		raw_beagle <- read.delim(infile, sep = " ", stringsAsFactors = F)
		samples <- names(raw_beagle[3:dim(raw_beagle)[2]])
		out_geno <- data.frame(scaffold = sub(":.+", "", raw_beagle[,2]), pos = as.numeric(sub(".+:", "", raw_beagle[,2])))
		raw_beagle <- read.delim(infile)
		raw_beagle_geno <- sub(".+:[0-9]+", "", raw_beagle[,1])
		out_geno[,"genotypes"] <- gsub(" ", "", raw_beagle_geno)	
	} else{
		if(file_format == "v"){
			vcf_file_prefix <- sub(".vcf", "", infile)
			sample_file <- sub(".vcf", "_sample.txt", infile)
			python_command <- paste("python ", prefix, "/vcfToGenotype.py -v ", infile, " -o ", vcf_file_prefix, sep = "")
			system(python_command)
			infile <- paste(vcf_file_prefix, "_GT.txt", sep = "")
			samples <- paste(rep(read.table(sample_file, stringsAsFactors = F, header = F)[,1], each = 2), 1:2, sep = "_")
		}
		out_geno <- read.delim(infile, sep = " ", stringsAsFactors = F, header = F)
		names(out_geno) <- c("scaffold", "pos", "genotypes")
		if (length(samples) == 1){
			samples <- paste("Ind", rep(1:(nchar(out_geno[1,3])/2), each = 2), 1:2, sep = "_")
		}		
	}
	out_geno[,1] <- as.character(out_geno[,1])	
	return(list(geno = out_geno, sample_list = samples))
}