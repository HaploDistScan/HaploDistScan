construct_window_annotation <- function(geno, interval= 100000){
	scaff_vec <- unique(geno[,1])
	max_vec <- c(geno[which(!duplicated(geno[,1]))[-1] - 1, 2], geno[dim(geno)[1],2])
	scaff_vec <- scaff_vec[max_vec > 2*interval]
	max_vec <- max_vec[max_vec > 2*interval]
	names(max_vec) <- scaff_vec

	scaffold_vec <- array()
	start_vec <- array()
	stop_vec <- array()
	start_cumulative_vec <- array()
	stop_cumulative_vec <- array()
	
	n_windows <- 1
	cumulative_pos <- 1
	for(scaff in scaff_vec){	
		max_val <- max_vec[scaff]
		scaff_starts <- seq(1, max_val, interval)
		scaff_stops <- c(seq(interval, max_val, interval), max_val)
		if(max_val %% interval == 0) scaff_stops <- c(seq(interval, max_val, interval))
		scaff_cumulative_starts <- scaff_starts + cumulative_pos - 1
		scaff_cumulative_stops <- scaff_stops + cumulative_pos - 1
		
		scaffold_vec[n_windows:(n_windows + length(scaff_stops) - 1)] <- scaff
		start_vec[n_windows:(n_windows + length(scaff_stops) - 1)] <- scaff_starts
		stop_vec[n_windows:(n_windows + length(scaff_stops) - 1)] <- scaff_stops
		start_cumulative_vec[n_windows:(n_windows + length(scaff_stops) - 1)] <- scaff_cumulative_starts
		stop_cumulative_vec[n_windows:(n_windows + length(scaff_stops) - 1)] <- scaff_cumulative_stops
		n_windows <- n_windows + length(scaff_stops)
		cumulative_pos <- max(scaff_cumulative_stops)
	}
	win_annot_df <- data.frame(scaffold = scaffold_vec, start = start_vec, stop = stop_vec, cumulative_start = start_cumulative_vec, cumulative_stop = stop_cumulative_vec, stringsAsFactors = F)
	return(win_annot_df)
}

