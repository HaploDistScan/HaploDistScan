### R code from vignette source 'HaploDistScan.Stex'

###################################################
### code chunk number 1: HaploDistScan.Stex:38-39 (eval = FALSE)
###################################################
## ruff_chr6 <- generate_geno_df("ruff_chr6_GT.txt")


###################################################
### code chunk number 2: HaploDistScan.Stex:41-43
###################################################
library(HaploDistScan)
data("ruff_chr6_genotypes")


###################################################
### code chunk number 3: HaploDistScan.Stex:47-49
###################################################
ruff_chr6_w <- construct_window_annotation(ruff_chr6$geno)
ruff_chr6_s <- calculate_haplotype_distances(ruff_chr6$geno, ruff_chr6_w)


###################################################
### code chunk number 4: HaploDistScan.Stex:53-54
###################################################
ruff_chr6_top_pos <- plot_hap_dist_scan(ruff_chr6_s, ruff_chr6_w, 50)


