#!/usr/bin/env python
# -*- coding: utf-8 -*-


import argparse
import sys


def vcf_parser(invcf, out_prefix):
    vcf_file = open(invcf, 'r')
    outfile = open(out_prefix + '_GT.txt', 'w')
    sample_file = open(out_prefix + '_sample.txt', 'w')

    for line in vcf_file:
        if not line.startswith('#'):
            items = line.strip().split('\t')
            chrom = items[0]
            position = items[1]
            alleles = {'0': items[3]}
            [alleles.update({str(i + 1) : str(v)}) for i, v in enumerate(items[4].split(','))]
            genotypes = items[9:]
            gt_list = []
            for gt in genotypes:
                if gt[0] in alleles.keys() and (gt[1] == '|' or gt[0] == gt[2]):
                    gt_list.extend([alleles[gt[0]], alleles[gt[2]]])
                else:
                    gt_list.append('NN')
            outfile.write(' '.join([chrom, position, ''.join(gt_list)]))
            outfile.write('\n')


        elif line.startswith('#CHROM'):
            sample_file.write('\n'.join(line.strip().split()[9:]))




if __name__ == '__main__':
    args = sys.argv[1:]
    parser = argparse.ArgumentParser(
        "Parses genotypes from a phased VCF to the minimal space delimited format used by HaploDistScan.")
    parser.add_argument('-v', '--vcf', help='Input VCF with phased genotypes.', required=True)
    parser.add_argument('-o', '--out_prefix',
                        help='Outputs genotypes in a minimal space delimited output file (prefix_GT.txt) and the sample list (prefix_Sample.txt).', required=True)
    arguments = parser.parse_args(args)

    vcf_parser(arguments.vcf, arguments.out_prefix)


